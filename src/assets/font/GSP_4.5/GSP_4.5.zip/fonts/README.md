# body font
Lowercase Scale-h97.5-PSB Bold-h1-PSB LBRat0
Light Thin-10 Move-v(-10) LSBat0 Weight-light +Space
Thin Thin-15 Move-v(-15) LSBat0 Weight-thin +Space
Regular Rep-arrows-SW-SE
Nodef=null
centered colon
case
l Move-TopRight-v30

- bolder 3 6
- rounded 30 (-> bold)
- high legible 01679GIJMQW

# condensed font
Scale-h90-PSB Bold-h6-PSB LSBat0 +Space

# headline font
Black Bold-5 Weight-Black
Medium no-case

# pixel
Medium Regular colonss2 RSB

# text
- bf centered colon ss03
- hf Medium ss03
