# Google Sans Plus Font
**Google Sans font for Android**

[![version](https://img.shields.io/badge/Version-4.5-brightgreen.svg)](https://github.com/nongthaihoang/google_sans_plus_font/releases/tag/v4.5) 
![updated](https://img.shields.io/badge/Updated-Oct_03,_2020-green.svg) 
[![forum](https://img.shields.io/badge/Forum-XDA-orange.svg)](https://forum.xda-developers.com/apps/magisk/font-headline-fonts-nongthaihoang-t3886349) 
[![download](https://img.shields.io/badge/Download-↓-yellow.svg)](https://github.com/nongthaihoang/google_sans_plus_font/releases)
[![donate](https://img.shields.io/badge/Donate-Paypal-blue.svg)](https://paypal.me/nongthaihoang)
 
## Description
Google Sans font with additional features and improvements.

## Previews
![img](https://raw.githubusercontent.com/nongthaihoang/gs_images/master/gsp/1.jpg)
![img](https://raw.githubusercontent.com/nongthaihoang/gs_images/master/gsp/2.jpg)
![img](https://raw.githubusercontent.com/nongthaihoang/gs_images/master/gsp/32.jpg)
![img](https://raw.githubusercontent.com/nongthaihoang/gs_images/master/gsp/42.jpg)
![img](https://raw.githubusercontent.com/nongthaihoang/gs_images/master/gsp/5.jpg)
![img](https://raw.githubusercontent.com/nongthaihoang/gs_images/master/gsp/6.jpg)

## Thanks
- [Magisk](https://github.com/topjohnwu/Magisk)
- [Volume-Key-Selector](https://github.com/Zackptg5/MMT-Extended-Addons/tree/master/Volume-Key-Selector)
